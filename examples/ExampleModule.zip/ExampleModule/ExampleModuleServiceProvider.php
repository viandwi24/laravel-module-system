<?php
namespace App\Modules\ExampleModule;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;
use Viandwi24\ModuleSystem\Interfaces\ModuleServiceProvider;

class ExampleModuleServiceProvider extends ServiceProvider implements ModuleServiceProvider
{
    public function register()
    {
        // load route
        Route::middleware('web')->group(__DIR__ . '/routes.php');
    }

    public function boot()
    {
        //
    }

    public function check()
    {
        return [
            'state' => 'ready'
        ];
    }
}