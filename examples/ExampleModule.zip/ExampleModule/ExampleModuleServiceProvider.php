<?php
namespace App\Modules\ExampleModule;

use Illuminate\Support\Facades\Route;
use Viandwi24\ModuleSystem\Base\Service;
use Viandwi24\ModuleSystem\Interfaces\ModuleInterface;

class ExampleModuleServiceProvider extends Service implements ModuleInterface
{
    public function register()
    {
        // load route
        Route::middleware('web')->group(__DIR__ . '/routes.php');
    }

    public function boot()
    {
        //
    }

    public function check()
    {
        return [
            'state' => 'ready'
        ];
    }
}