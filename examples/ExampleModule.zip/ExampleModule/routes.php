<?php

use Illuminate\Support\Facades\Route;

Route::get('/tes', function () {
    return "hello world!";
});